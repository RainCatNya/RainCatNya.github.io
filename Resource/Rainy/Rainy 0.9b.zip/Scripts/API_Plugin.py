from pathlib import Path
import importlib.util
import json, sys

class Plugin:
    "雨猫酱的插件管理器"
    
    def __init__(self, path):
        from Scripts import Raistra
        self.Plugins_dir = Path(path)
        self.Plugins = dict()
        self.__THEME__ = Raistra.theme
        
    def run(self):
        self.Unload()
        return self.ReLoad()
        
    def Unload(self):
        ...
        
    def ReLoad(self):
        "初始化模块"
        from Scripts import Raistra
        
        if not self.Plugins_dir.exists():
            "插件目录若不存在"
            return {}
        
        "插件加载的统计数据"        
        __ACTIVE__ = 0
        __DISACTIVE__ = 0
        __ERROR__ = 0
        
        for folder in self.Plugins_dir.iterdir():
            "遍历所有插件文件夹"
            if not folder.is_dir():
                "不检查非目录对象"
                continue
            
            pkg_file = folder / "package.json"
            if not pkg_file.exists():
                "文件夹下若没有package.json则不视为插件"
                continue
            
            "读取package.json"
            try:
                with open(pkg_file, "r", encoding="utf-8") as f:
                    pkg_data = json.load(f)
            except Exception as e:
                continue
            
            "读取package.name"
            name = pkg_data.get("name")
            if not name:
                Raistra.log(f'有一个名称未知插件的package.json不存在name属性, 路径{pkg_file}', s='Plugin', lv=3, t=True)
                continue
            
            "查找版本号"
            version = pkg_data.get("version")
            if not version:
                version = ''
                Raistra.log(f'未找到插件 <font color=#ff7f50>{name}</font> 的版本号', s='Plugin', lv=3, t=True)
                
            "如果已禁用则不加载"
            if not pkg_data.get("enabled", True):
                Raistra.log(f'插件 <font color=#999999>{name}</font> <font color=#999999> ({version})</font> 被禁用, 跳过加载', s='Plugin', t=True)
                __DISACTIVE__ += 1
                continue

            "查找入口文件"
            entry_file = folder / pkg_data.get("main")
            if not entry_file.exists():
                "若入口文件不存在则跳过"
                Raistra.log(f'未找到插件 <font color=#ff0000>{name}</font> 的构建文件main.py', s='Plugin', lv=4, t=True)
                __ERROR__ += 1
                continue
       
            "查找图标"
            icon = folder / pkg_data.get("icon")
            if not icon.exists() or pkg_data.get("icon") == '':
                icon = None
                Raistra.log(f'未找到插件 <font color=#ff7f50>{name}</font> 的图标文件', s='Plugin', lv=3, t=True)
            
            "依据Path转化为module"
            spec = importlib.util.spec_from_file_location(name, entry_file)
            if not spec or not spec.loader:
                Raistra.log(f'加载插件 <font color=#ff0000>{name}</font> 时发生了雨猫都不知道是什么的错误...', s='Plugin', lv=4, t=True)
                __ERROR__ += 1
                continue
            
            "转化为ModuleSpec对象"
            module = importlib.util.module_from_spec(spec)
            "将插件目录临时添加到Path 以便插件导入自己的内部模块"
            plugin_dir = str(entry_file.parent)
            sys.path.insert(0, plugin_dir)
            try:
                "加载模块代码"
                spec.loader.exec_module(module)
            except Exception as e:
                Raistra.log(f'插件 <font color=#ff0000>{name}</font> 的代码存在显式错误:<br> <font color=#ff6666>{e}</font>', s='Plugin', lv=4, t=True)
                __ERROR__ += 1
                continue
            finally:
                "移除插件临时目录"
                sys.path.pop(0)
            
            try:
                "所有插件必须有callable的构建方法"
                build = getattr(module, 'build')
                if not callable(build):
                    Raistra.log(f'插件 <font color=#ff0000>{name}</font> 的build方法没有__call__属性', s='Plugin', lv=4, t=True)
                    __ERROR__ += 1
                    continue
            except Exception as e:
                Raistra.log(f'加载插件 <font color=#ff0000>{name}</font> 时遇到了错误: <font color=#ff6666>{e}</font>', s='Plugin', lv=4, t=True)
                __ERROR__ += 1
                continue
            
            # "尝试构建 检查代码是否存在隐式错误"
            # try:
            #     build()
            # except Exception as e:
            #     Raistra.log(f'插件 <font color=#ff0000>{name}</font> 的代码存在运行时错误:<br> <font color=#ff6666>{e}</font>', s='Plugin', lv=4, t=True)
            #     __ERROR__ += 1
            #     continue
            
            "加载完成"
            Raistra.log(f'插件 <font color={self.__THEME__}>{name}</font><font color=#999999> ({version})</font> 加载完成', s='Plugin', t=True)
            self.Plugins[name] = {"build": build, "pkg_data": pkg_data, "icon":icon}
            __ACTIVE__ += 1
            
        Raistra.log(f'插件加载完成 <font color=#999999>[活跃:{__ACTIVE__}, 禁用:{__DISACTIVE__}, 错误:{__ERROR__}]</font>')
        "有错误时打开日志"
        if __ERROR__ or not __ACTIVE__:
            "出错或者没有激活的插件时调出日志"
            Raistra.signal.sLog_Requested.emit()
            
        "返回所有插件数据"
        return {name: {'build':info['build'], 'icon':info['icon']} for name, info in self.Plugins.items()}