"这是`Raistra`的存储文件`Raistrar.py`, Raistrar既不是类也不是实例！"
from PyQt6.QtCore import QObject

class cRaistra(QObject):
    """*雨坠星空！*  
    整个`Rainy`的初始化核心, 挂载程序所需的所有内容"""
    
    __version__ = '0.9r'
    "`Raistra Version`"
    
    "特殊命名规范 - Raincat倾情呈现"
    "类x -> cX"
    "实例x -> iX"
    "信号x -> sX"
     
    def __init__(self):
        "`Raistra`初始化"
        super().__init__()
        
        "阻止再次初始化"
        if hasattr(self, '_initialized') and self._initialized:
            return
        self._initialized = True
        
        "起朱楼"
        self._mount()
        
        "宴宾客"
        self._instantiate()
        
        "启明灯"
        self._bootstrap()
        
        "映星辰"
        self._connect()
        
    "防止 cRaistra 被继承"
    def __init_subclass__(cls, **kwargs) -> None:
        raise TypeError(
            f"class '{cls.__name__}' is not allowed to inherit from 'Raistra_Class'")
    
    _instance = None
    "实例化标签, 存储本类的实例"

    "防止 cRaistra 被多次实例化"
    def __new__(cls, *args, **kwargs):
        if cls._instance is not None:
            raise TypeError(
                f"'{cls.__name__}' is a singleton and cannot be instantiated directly. "
                "Use the global 'Raistra' instance instead.")
        instance = super().__new__(cls)
        cls._instance = instance
        return instance
    
    def _mount(self):
        "`Raistra`: 挂载API方法, 使其可被外部直接调用"
        from . import API_FileOpreation
        self.read_File = API_FileOpreation.read_File
        self.read_File_Byte = API_FileOpreation.read_File_Byte
        self.read_Json = API_FileOpreation.read_Json
        
        from . import RY_Widgets
        self.RyWidget = RY_Widgets
        
    def _instantiate(self):
        "`Raistra`: 实例化并储存管理器实例"
        "在大多数情况下, 不应直接访问这些实例"
        from . import API_Log, API_Rainy, API_Style, API_Settings
        self._iLogger = API_Log.cLogger()
        self._iRainar = API_Rainy.cRainar()
        self._iStyle = API_Style.cStyle()
        self._iSetting = API_Settings.cSettings()
        
        "挂载单例"
        from .API_SignalBus import iBus
        self.signal = iBus
        
        "挂载实例方法"
        self.log = self._iLogger.log
        self.blog = self._iLogger.blog
        self.launch = self._iRainar.Launch
        
    def _bootstrap(self):
        "`Raistra`: 引导并启动Rainy"
        "阶段1 / 加载配置"
        self.blog("加载配置")
        self.config = self._iSetting.config
        self.blog("<br>".join(self._iSetting.printcfg(self.config)))
    
        "阶段2 / 设置样式表"
        self.theme = self._iStyle.theme
        self.theme = self.config['rainy.theme']['value']
        self.css_path = "Stylesheets/dark_violet.css"
        self.blog("<br>加载样式表")
        self.blog(f'<font color=#999999>已加载样式表 </font>{self.css_path}</font>')
        if self._iStyle.isHex(self.theme):
            self.blog(f'<font color=#999999>已应用主题色 </font><font color={self.theme}>{self.theme}</font>')
        else:
            self.log(f'错误的主题色: {self.theme}', lv=4)
            self.theme = '#ffffff'
            self.log(f'设置为默认主题色: {self.theme}', lv=1)

        self.blog(f'<font color=#999999>可用样式文件 </font>2')
        
    def _connect(self):
        "`Raistra`: 连接信号"
        "连接信号"
        self.signal.sLog_setMaxLine.connect(lambda value:self._iLogger.setMaxLine(value))
        
        "信号: 关闭Rainy"
        self.signal.sShutdown.connect(lambda: self.log('已接收终止信号 sShutdown',t=True))
        self.signal.sShutdown.connect(lambda: self._iRainar.Shutdown())