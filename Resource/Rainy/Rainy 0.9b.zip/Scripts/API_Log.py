"`RaistraAPI.Log`模块"
from PyQt6.QtCore import QObject
from collections import deque
import datetime

"导入信号"
from .API_SignalBus import iBus

class cLogger(QObject):
    "`Raistra`日志记录器"
    
    def __init__(self):
        super().__init__()
        
        "日志容器"
        self.logBuffer = deque(maxlen=self.__MAX_LINE__)
        "带HTML的日志, 用于在Rainy内查看"
        self.logBuffer_raw = deque(maxlen=self.__MAX_LINE__)
        "纯文本日志, 仅用于导出查看; 不限长度"
        "deque环形缓冲区为了避免日志内容过大 > 占满内存&卡崩渲染:)"
        
    "某处贴示的公告"
    "只有调用方有权调用日志, API及方法本身无权写入日志"
    
    "定义常量"
    __MAX_LINE__ = 1000
    "日志最大行数, 由Raistra在配置中读取"

    __LV__ = ['',
                  '<font color=#999999>[信息]</font>', 
                  '<font color=#ffffff>[提醒]</font>',
                  '<font color=#ff7f50>[警告]</font>',
                  '<font color=#ff4444>[错误]</font>',
                  '<font color=#ff0000>[致命]</font>']
    "日志等级"
    __LV_RAW__ = ['', '[信息]', '[提醒]', '[警告]', '[错误]', '[致命]']

    "定义方法"    
    def log(self, msg:str, t=False, s='', lv=1) -> None:
        "`Log`记录文本"
        "此方法不被信号连接, 只对外暴露(主要是为了效率)"
        time = f"[{datetime.datetime.now().strftime('%H:%M:%S')}]" if t else ''
        source = f"[{s}]" if s else ''
        "写入文本"
        self.logBuffer.append(f"<font color=#999999>{time}{source}{self.__LV__[lv]}</font> {msg}<br>")
        self.logBuffer_raw.append(f"{time}{source}{self.__LV__[lv]} {msg}\n")
        "发射更新信号"
        iBus.sLog_update.emit()
        
    def blog(self, msg:str):
        "`Log`直接记录文本, 无需任何提示`(blank_log)`"
        self.logBuffer.append(f"{msg}<br>")
        self.logBuffer_raw.append(f"{msg}\n")
        "发射更新信号"
        iBus.sLog_update.emit()
        
    def log_export(self):
        "`log`导出日志"
        import os
        from datetime import datetime
        
        # 确保 logs 文件夹存在
        os.makedirs("logs", exist_ok=True)
        
        # 用时间戳命名
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filepath = f"logs/rainy_crash_{timestamp}.log"
        
        # 写入纯文本日志
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(self.getLog_raw())
        
        # 顺便在界面上提示一下（可选）
        self.log(f"日志已导出到 {filepath}", t=True, s="Logger", lv=1)
        
    def setMaxLine(self, value:int):
        "`setter`更新常量`__MAX_LINE__`, 重载两个缓冲区"
        self.__MAX_LINE__ = value
        self.logBuffer = deque(list(self.logBuffer), maxlen=value)
        self.logBuffer_raw = deque(list(self.logBuffer_raw), maxlen=value)
        "建议只在读取配置时更新一次"
        
    def getLog_html(self):
        "`getter`获取HTML格式日志"
        return "".join(self.logBuffer)
        
    def getLog_raw(self):
        "`getter`获取纯文本日志"
        return "".join(self.logBuffer_raw)