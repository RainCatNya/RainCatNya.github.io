"""存有所有RainyAPI实现  
只能从`Raistra`调用"""

"不要直接运行这个文件;)"
from .Raistrar import cRaistra
Raistra = cRaistra()
"`RainyAPI Library`"

__all__ = ['Raistra']
"仅暴露`Raistra`实例"