"文件操作模块"

"只捕获预期异常, 如果真的有预期之外的异常则向上抛出让程序崩溃"
"如捕获了异常, 返回None让调用方决定异常处理; API本身不负责任何异常处理"
import pathlib
def read_File(path:str, encoding='utf-8') -> str | None:
    "`API`: 以`text`格式读取文件"
    File = pathlib.Path(path)
    try:
        with File.open(mode='r', encoding=encoding) as f:
            return f.read()
    except (UnicodeDecodeError, OSError):
        return None
    
def read_File_Byte(path:str) -> bytes | None:
    "`API`: 以`bytes`格式读取文件"
    File = pathlib.Path(path)
    try:
        return File.read_bytes()
    except OSError:
        return None

import json
def read_Json(path:str, encoding='utf-8') -> dict | None:
    "`API`: 读取`JSON`文件"
    File = pathlib.Path(path)
    try:
        with File.open(mode='r', encoding=encoding) as f:
            return json.load(f)
    except (UnicodeDecodeError, OSError):
        return None