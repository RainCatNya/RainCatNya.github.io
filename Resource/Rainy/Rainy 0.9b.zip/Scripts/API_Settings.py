"文本编码兼键值对储存和移动师"
from PyQt6.QtCore import QObject
from .API_FileOpreation import *

"导入信号"
from .API_SignalBus import iBus

class cSettings(QObject):
    "`Raistra`设置管理器"

    def __init__(self):
        "设置项初始化"
        
        self.__default__ = read_Json(self.__path_default__)
        assert self.__default__ is not None
        "断言默认配置存在, 换言之, 如果默认配置都不存在, 那程序就没什么运行的意义了"
        self.__user__ = self.get_usercfg(self.__path_user__)
        
        self.config = self.Merge(self.__default__, self.__user__)
    
    __path_default__ = 'Scripts/Settings_default.json'
    "默认配置 (只读)"
    __path_user__ = 'settings.json'
    "用户配置"

    def get_usercfg(self, path_user:str=__path_user__) -> dict:
        "读取用户配置字典"
        __user__ = read_Json(path_user)
        if not __user__:
            __user__ = {}
        return __user__
    
    def Merge(self, default:dict, user:dict) -> dict:
        "合并用户配置和默认配置"
        
        def run(base: dict, override: dict) -> dict:
            "递归合并字典"
            result = base.copy()
            for key, value in override.items():
                if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                    result[key] =run(result[key], value)
                elif key in result and isinstance(result[key], dict) and 'value' in result[key] and not isinstance(value, dict):
                    result[key]['value'] = value
                else:
                    result[key] = value
            return result
        
        return run(default, user)
    
    def printcfg(self, config: dict, prefix: str = "") -> list:
        "以文本格式输出键值对"
        "其实就是把字典的每个键值拼在一起了("
        lines = []
        for key, value in config.items():
            full_key = f"{prefix}.{key}" if prefix else key
            if isinstance(value, dict):
                if "value" in value:
                    lines.append(f"<font color=#999999>{full_key}</font>: {value['value']}")
                else:
                    lines.append(self.printcfg(value, full_key))
            else:
                lines.append(f"{full_key}: {value}")
        return lines