from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QPushButton

class RPushButton(QPushButton):
    "雨猫桑的御用PushButton按钮"

    "定义信号"
    hover = pyqtSignal(bool)
        
    def enterEvent(self, event) -> None:
        "重写鼠标进入事件"
        if self.isEnabled():
            self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        "重写鼠标离开事件"
        if self.isEnabled():
            self.hover.emit(False)
        super().leaveEvent(event)