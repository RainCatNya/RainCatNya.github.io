from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QPushButton

class RToggle(QPushButton):
    "雨猫桑的御用Toggle红绿灯"
    
    def __init__(self, text:str = '', state:bool = False) -> None:
        "构建RToggle"
        self.toggled: bool = state
        super().__init__()
        
        "初始化样式"
        self.setText(text)
        self.updateStyle()
    
    "定义信号"
    hover = pyqtSignal(bool)
        
    def enterEvent(self, event) -> None:
        "重写鼠标进入事件"
        if self.isEnabled():
            self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        "重写鼠标离开事件"
        if self.isEnabled():
            self.hover.emit(False)
        super().leaveEvent(event)
    
    def mousePressEvent(self, e) -> None:
        "重载鼠标点击事件"
        self.toggled = not self.toggled        
        self.updateStyle()
        return super().mousePressEvent(e)

    def updateStyle(self) -> None:
        "更新状态样式"
        if self.toggled:
            self.setStyleSheet("""
                RToggle {
                    padding: 7px;
                    border: 2px solid #34a634;
                    background-color: transparent
                }
                RToggle:hover {
                    padding: 6px;
                    border: 3px solid #34a634;
                    background-color: rgba(52, 166, 52, 10)
                }
            """)
        else:
            self.setStyleSheet("""
                RToggle {
                    padding: 7px;
                    border: 2px solid #b83f3f;
                    background-color: transparent
                }
                RToggle:hover {
                    padding: 6px;
                    border: 3px solid #b83f3f;
                    background-color: rgba(184, 63, 63, 10)
                }
        """)
        "更新图形"
        self.style().unpolish(self) # type: ignore
        self.style().polish(self) # type: ignore