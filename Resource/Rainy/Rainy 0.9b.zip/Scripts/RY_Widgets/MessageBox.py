from PyQt6.QtWidgets import QWidget
from Scripts import Raistra

class rMessagebox(QWidget):
    
    ...