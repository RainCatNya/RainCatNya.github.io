from PyQt6.QtWidgets import QComboBox
from PyQt6.QtCore import pyqtSignal, Qt

class RComboBox(QComboBox):
    "雨猫桑的御用下拉框"

    def __init__(self, items: list = []):
        "构建RComboBox"
        super().__init__()
        for item in items:
            self.addItem(item)
        
        self.view().window().setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint | Qt.WindowType.NoDropShadowWindowHint) # type: ignore
        self.view().window().setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground) # type: ignore
    
    "定义信号"
    sig_popup = pyqtSignal()
    hover = pyqtSignal(bool)
    
    def enterEvent(self, event) -> None:
        "重写鼠标进入事件"
        if self.isEnabled():
            self.hover.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:
        "重写鼠标离开事件"
        if self.isEnabled():
            self.hover.emit(False)
        super().leaveEvent(event)

    def showPopup(self) -> None:
        self.sig_popup.emit()
        
        "重写下拉框展出动画"
        super().showPopup()
        popup = self.view().window() # type: ignore
        popup.move(popup.x(), popup.y()+4) # type: ignore
