from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import QWidget

class cStyle(QObject):
    
    def __init__(self):
        super().__init__()
        self.__theme__:str = ''
        "`Style`: 主题色"
    
    @property
    def theme(self):
       return self.__theme__
   
    @theme.setter
    def theme(self, value):
        if self.isHex(value):
            self.__theme__ = value
   
    def isHex(self, value:str):
        "检验是否为Hex"
        HEX_CHARS = set('0123456789ABCDEFabcdef')
        return (len(value) == 7 and
                value[0] == '#' and
                all(c in HEX_CHARS for c in value[1:]))