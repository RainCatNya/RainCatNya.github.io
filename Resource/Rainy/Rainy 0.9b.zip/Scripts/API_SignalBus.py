"信号总线模式!"
from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import QWidget

class cSignalBus(QObject):
    "`Raistra`信号总线"
    
    def __init__(self):
        super().__init__()
        
    "某处贴示的公告"
    "核!心!精神是解耦, 只发射信号, 不在API或插件里调用实现也不通过import调用实现"
    
    "生命周期相关"
    sCritical = pyqtSignal(str)
    "`Signal`: 将程序崩溃事件`(message: str)`写入后导出日志 & 关闭Rainy | 接受方: `iRainy, iLogger`"
    sShutdown = pyqtSignal()
    "`Signal`: 关闭Rainy | 接受方: `iRainy`"
    
    "Rainy视图相关"
    "接受方: iRainy(理所当然的)"
    sRainy_changeTitle = pyqtSignal(str)
    "`Signal`: 更改 Rainy 的标题文本`(value: str)`"
    sRainy_Resize = pyqtSignal(int, int)
    "`Signal`: 更改 Rainy 的窗口大小`(width, height: int, int)`"
    sRainy_switchPage = pyqtSignal(QWidget)
    "`Signal`: 切换到某页面`(page: QWidget)`"
    sRainy_switchPage_Index = pyqtSignal(QWidget)
    "`Signal`: 切换到某序号对应的页面`(value: int)`"
    sRainy_Minimize = pyqtSignal()
    "`Signal`: 最小化 Rainy 窗口"
    
    "日志记录相关"
    "接受方: iLogger(更理所当然的)"
    sLog_Export = pyqtSignal()
    "`Signal`: 导出日志"
    sLog_Copy = pyqtSignal()
    "`Signal`: 将当前日志复制到剪贴板"
    sLog_update = pyqtSignal()
    "`Signal`: 更新日志"
    sLog_setMaxLine = pyqtSignal(int)
    "`Signal`: 更新日志缓冲区长度`(value: int)`"
    sLog_Requested = pyqtSignal()
    "`Signal`: 显示并切换到日志页 | 接受方: `Rainy`"
    
    "样式相关"
    "接受方: iStyle(怎么感觉像苹果, iPy)"
    sStyle_Load = pyqtSignal(str)
    "`Signal`: 加载并应用指定的样式表`(CSSContent: str)`"
    sStyle_Reload = pyqtSignal(str)
    "`Signal`: 卸载并应用新的样式表`(CSSContent: str)`"
    
    "设置相关"
    "接受方: iSetting(相当理所当然的)"
    sSetting_Merge = pyqtSignal(str, str)
    "`Singal`: 合并用户配置和默认配置`(cfg_user, cfg_default: str, str)`"
    
iBus = cSignalBus()
"`instance`: 信号总线全局单例"