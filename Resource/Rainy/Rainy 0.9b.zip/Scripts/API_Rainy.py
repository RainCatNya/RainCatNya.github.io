"`Raistra`Rainar模块"
from PyQt6.QtCore import QObject
from PyQt6.QtWidgets import QApplication
import sys

class cRainar(QObject):
    "`Raistra`Rainy控制器"
    "管理整个Rainy的生命周期"
    
    __running__ = False
    
    def __init__(self):
        "`Rainar`初始化"
        sys.excepthook = self.Rainy_gloabl_exception_handler
        
    def Rainy_gloabl_exception_handler(self, exc_type, exc_value, exc_tb):
        "`Rainy`全局异常钩子"
        sys.__excepthook__(exc_type, exc_value, exc_tb)
        self.__running__ = False
        QApplication.quit()
    
    "Rainy API实现"
    def Launch(self):
        "`API`: 启动Rainy"
        if not self.__running__:
            from Rainy import Rainy
            import sys
            app = QApplication(sys.argv)
            self.rainy_Instance = Rainy()
            self.__running__ = True
            app.exec()
        
    def Shutdown(self):
        "`API`: 关闭Rainy进程"
        if self.__running__:
            self.rainy_Instance.deleteLater()
            self.__running__ = False
        
    def get_Instance(self):
        "`getter`: 获取Rainy实例"
        if self.__running__:
            "你都没初始化要什么实例? 哈?!"
            return self.rainy_Instance
        
    def set_WindowTitle(self, value:str):
        "`API`: 更改Rainy窗口标题"
        if self.__running__:
            self.rainy_Instance.setWindowTitle(value)