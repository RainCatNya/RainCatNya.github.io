from PyQt6.QtWidgets import (QWidget, QVBoxLayout,
    QLineEdit, QHBoxLayout, QLabel, QPushButton, QScrollArea)
from PyQt6.QtCore import Qt

def build(theme:str) -> QWidget:
    "Rainy 日志"
    
    "基本框架构建"
    Scroll = QScrollArea()
    Scroll.setWidgetResizable(False)
    Layout = QVBoxLayout(Scroll)
    
    __THEME__ = theme
    
    "标题"
    Text_Title = QLabel(f'<font size=3><font color={__THEME__}>{build.__doc__}</font><br><font color=#777777><font size=2>Someday I hope to see you here, Far far away countless light-years..')
    Layout.addWidget(Text_Title)
    
    "提示栏"
    Text_Tip = QLabel('<font color=#999999>雨猫QQ: SGkgZ2V0aGluZS4uIFlvdSBzaG91bGQgYWxyZWFkeSBrbm93IHRoYXQ/')
    Layout.addWidget(Text_Tip)
    
    "日志内容"
    Scroll_log = QScrollArea()
    Scroll_log.setWidgetResizable(True) 
    Scroll_log.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    Scroll_log.setStyleSheet('background-color: #222222')
    
    Container = QWidget()      
    Layout_log = QVBoxLayout(Container)
    Scroll_log.setWidget(Container)

    Text_log = QLabel()
    Text_log.setObjectName('Log')
    Text_log.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    Text_log.setWordWrap(True)
    Layout_log.addWidget(Text_log)
    Layout_log.addStretch(1)
    
    Layout.addWidget(Scroll_log)
    return Scroll