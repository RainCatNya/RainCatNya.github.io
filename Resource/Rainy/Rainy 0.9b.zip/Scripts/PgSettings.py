from PyQt6.QtWidgets import (QWidget, QVBoxLayout,
    QLineEdit, QHBoxLayout, QLabel, QPushButton, QScrollArea)
from PyQt6.QtCore import Qt

def build(theme:str) -> QWidget:
    "Rainy 设置项"
    
    "基本框架构建"
    Scroll = QScrollArea()
    Scroll.setWidgetResizable(False)
    Layout = QVBoxLayout(Scroll)
    
    __THEME__ = theme
    
    "标题"
    Text_Title = QLabel(f'<font size=3><font color={__THEME__}>{build.__doc__}</font><br><font color=#777777><font size=2>在此处对 Rainy 和不同插件提供的参数进行修改')
    Layout.addWidget(Text_Title)
    
    "设置内容"
    Scroll_log = QScrollArea()
    Scroll_log.setWidgetResizable(True) 
    Scroll_log.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    
    Container = QWidget()      
    Layout_log = QVBoxLayout(Container)
    Scroll_log.setWidget(Container)
    
    Layout.addWidget(Scroll_log)
    return Scroll