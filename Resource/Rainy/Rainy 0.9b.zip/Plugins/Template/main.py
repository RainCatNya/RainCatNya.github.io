"""
本模板为 Rainy 插件开发提供标准结构。
请严格遵循以下规范，以确保插件稳定兼容。
任何违反规范的行为可能导致程序异常或崩溃。

This template provides the standard structure for Rainy plugin development.
Please follow these guidelines strictly to ensure stability and compatibility.
Violating these rules may cause unexpected errors or crashes.
"""

from PyQt6.QtWidgets import QWidget
from Scripts import Raistra
"""
导入
  在绝大多数情况下, 请导入Raistra, 不要直接导入Scripts模块下的API,
  Raistra挂载了可以正确使用的方法, 如果直接使用可能造成程序错误乃至崩溃
  更多关于插件的说明请查看帮助文档

Import
  In most cases, please import Raistra instead of directly importing APIs from the Scripts module.
  Raistra mounts methods that can be used correctly, and using them directly might cause program errors or even crashes.
  For more information about the plugin, please check the help documentation.
"""

def build():
    
    Widget = QWidget()
    """
    构造方法
      插件的入口函数，必须返回一个 QWidget 作为插件页面。
      该函数不应接受任何参数，也不应执行耗时阻塞操作。
      所有初始化工作应在此函数内完成。
    
    Constructor
      The entry point of your plugin. Must return a QWidget as the plugin page.
      This function should not accept any parameters, nor perform long-blocking operations.
      All initialization should be done inside this function.
    """
    
    TestButton = Raistra.RyWidget.RPushButton()
    """
    组件
      您可以使用任何标准 Qt 组件，也可以使用 Raistra.CM 下的 R 系列自定义组件，
      例如: RPushButton, RComboBox, RToggle 等。

    Components
      You can use any standard Qt widgets, or use the custom R-series components
      under Raistra.CM (e.g., RPushButton, RComboBox, RToggle).
    """
    
    def dangerOpreation():
        "请不要这么做。 Please do NOT do that."
        DangerCode = ''
        
        eval(DangerCode)
        getattr(__builtins__,'eval')(DangerCode)
    """
    限制
      请不要在此处放置任何危险方法, 无论是否出于何目的
      请勿在插件中执行任何可能危害系统、用户数据或隐私的操作。
      包括但不限于：删除文件、修改系统设置、未经同意上传数据。
    
    Restrictions
      Please don't place any dangerous methods here, no matter what the purpose is.
      Do NOT perform any operations that may compromise system stability,
      deleting files, modifying system settings, uploading data without consent.
    """
    
"""
更多帮助
  请参阅 Rainy 插件开发文档获取完整 API 说明和最佳实践。
  
Further Help
  Refer to the Rainy Plugin Development Documentation for the full API reference
  and best practices.
"""