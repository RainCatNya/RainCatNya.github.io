"Formatar支持库"

from PyQt6.QtWidgets import QFileDialog
def pick_file(title:str = '选择文件', Type:str = '所有文件 (*.*)') -> str:
    "选取文件"
    "type的每个格式种类用;;分隔"
    file_path, _ = QFileDialog.getOpenFileName(None, title, '', Type)
    "取消选择时返回None"
    return file_path if file_path else ''

def pick_dir(title:str = '选择文件夹') -> str:
    "选择目录"
    folder_path = QFileDialog.getExistingDirectory(None, title, '')
    return folder_path if folder_path else ''

from PyQt6.QtCore import QThread, pyqtSignal
from moviepy import VideoFileClip
from proglog import ProgressBarLogger
class ProgressLogger(ProgressBarLogger):
    def __init__(self, progress_signal):
        super().__init__()
        self.progress_signal = progress_signal

    def bars_callback(self, bar, attr, value, old_value=None):

        total = self.bars[bar]['total']   # 总迭代次数
        if total > 0:
            percentage = int((value / total) * 100)
            self.progress_signal.emit(percentage)

class ConvertThread(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, origin_format, target_format ,target, output_dir, name):
        super().__init__()
        self.target = target
        self.output_dir = output_dir
        self.name = name
        self.origin_format = origin_format
        self.target_format = target_format

    def run(self):
        "在线程创建时执行的操作"
        try:
            self.progress.emit(0)
            "根据原格式和目标格式切换模式"
            if self.origin_format == 'mp4' and self.target_format == 'mp3':
                self.mp4_to_mp3()
        except Exception as e:
            print(str(e))
            self.error.emit(str(e))
            
    def mp4_to_mp3(self):
        "mp4转mp3"
        video = VideoFileClip(self.target)
        audio = video.audio
        if audio is None:
            raise ValueError("视频中没有音频轨道")
        out_path = f"{self.output_dir}{self.name}.mp3" if self.output_dir else f"{self.name}.mp3"
        logger = ProgressLogger(self.progress)
        audio.write_audiofile(out_path, codec='libmp3lame', logger=logger)
        self.progress.emit(100)
        self.finished.emit(out_path)
            
import os
def find_files(directory, extension):
    files = []
    for root, dirs, filenames in os.walk(directory):
        for f in filenames:
            if f.endswith(extension):
                files.append(os.path.join(root, f))
    return files