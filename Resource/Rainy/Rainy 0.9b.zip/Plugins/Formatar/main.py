from PyQt6.QtWidgets import (QWidget, QVBoxLayout,
    QHBoxLayout, QLabel, QScrollArea, QProgressBar)
from formatar_lib import *
from Scripts import Raistra
from pathlib import Path

from Scripts import *

def build() -> QWidget:
    "Formatar 转化桌"
    Scroll = QScrollArea()
    Scroll.setWidgetResizable(False)
    Layout = QVBoxLayout(Scroll)
    
    "插件信息"
    __version__ = '0.7a'
    __THEME__ = Raistra.theme
    __cridit__ = '雨猫Sama'
        
    "插件标题"
    Text_Title = QLabel(f'<font color={__THEME__}>{build.__doc__}</font><br><font color=#777777><font size=2>版本 {__version__} by {__cridit__}</font>')
    Layout.addWidget(Text_Title)

    "模式"
    "内部变量名 / 显示名称"
    __MODE_DICT__ = {'format_Conv': '格式转化 Format Convert'}
    
    "全局变量"
    __ORIGIN_FORMAT__:str = ''
    __TARGET_FORMAT__:str = ''
    
    __OUTPUT__:str = ''
    __TARGET__:str = ''
    __TARGET_FOLDER__:str = ''
    __TARGET_LIST__:list = []
    
    __NAME__:str = ''
    __TARGET_BASENAME__:str = ''
    __NAME_IS_VAILD__:bool =  True
    
    __RUNNING__:bool = False
    worker = None
    
    def update_Layout():
        ...
    
    def update_Tootip(hover: bool, text: str):
        "更新提示词"
        if hover:
            Text_Tip.show()
            Text_Tip.setText(text)
        else:
            Text_Tip.hide()
        
    def update_Ctrl(stat: bool):
        "更新交互组件状态"
        nonlocal __RUNNING__
        __RUNNING__ = not stat
        Btn_Pick.setEnabled(stat)
        Btn_Pick_Output.setEnabled(stat)
        Btn_Exec.setEnabled(stat)
        Btn_Exec_Muilt.setEnabled(stat)
        Btn_Pick_Folder.setEnabled(stat)

        if stat:
            Verfi_Target()
            Verfi_Target_Mulit()
            Cbox_Format_Origin.show()
            Cbox_Format_Target.show()
            Text_Current_Mode.hide()
            Cbox_Mode.show()
            Text_Tip.show()
            Text_Format_Convert.setMaximumWidth(60)
            Text_Format_Convert.setText('> 转化 >')
        else:
            Cbox_Format_Origin.hide()
            Cbox_Format_Target.hide()
            Cbox_Mode.hide()
            Text_Current_Mode.show()
            Text_Tip.hide()
            Text_Format_Convert.setMaximumWidth(1000)
            Text_Format_Convert.setText(f'{__ORIGIN_FORMAT__} 转化为 {__TARGET_FORMAT__}')
    
    def Select_File():
        "选取文件"
        nonlocal __TARGET__, __TARGET_BASENAME__
        __TARGET__ = pick_file(f'选择.{__ORIGIN_FORMAT__}文件', f'指定格式 (*.{__ORIGIN_FORMAT__})')
        __TARGET_BASENAME__ = Path(__TARGET__).stem
        Verfi_Target()
        
    def Select_Folder():
        "选择目标文件夹"
        nonlocal __TARGET_FOLDER__, __TARGET_LIST__
        __TARGET_FOLDER__ = pick_dir(f'选择一个充~满了.{__ORIGIN_FORMAT__}文件的文件夹')
        __TARGET_LIST__ = find_files(__TARGET_FOLDER__,f'.{__ORIGIN_FORMAT__}')
        Verfi_Target_Mulit()
        
    def Select_OutputFolder():
        "选取输出文件夹"
        nonlocal __OUTPUT__
        __OUTPUT__ = pick_dir('选择输出文件夹')
        
    def Open_OutputFolder():
        import os
        if not __OUTPUT__:
            os.startfile(os.path.dirname(__OUTPUT__))
        else:
            os.startfile(__OUTPUT__)
        
    def Verfi_Target():
        "当不再运行时检验是否可以进行单次转换"
        if not __RUNNING__:
            if not __TARGET__:
                Btn_Exec.setEnabled(False)
            else:
                Btn_Exec.setEnabled(True)
            
    def Verfi_Target_Mulit():
        "当不再运行时检验是否可以进行批量转换"
        if not __RUNNING__:
            if len(__TARGET_LIST__) >= 1:
                Btn_Exec_Muilt.setEnabled(True)
            else:
                Btn_Exec_Muilt.setEnabled(False)
            
    def Verfi_Format():
        nonlocal __ORIGIN_FORMAT__, __TARGET_FORMAT__
        __ORIGIN_FORMAT__ = __FORMAT_LIST_ORIGIN__[Cbox_Format_Origin.currentIndex()]
        __TARGET_FORMAT__ = __FORMAT_LIST_TARGET__[Cbox_Format_Target.currentIndex()]
        
    def Exec():
        "执行单次转换"
        nonlocal __NAME__
        
        "当文件名为空时将输出文件名设置为源文件名"
        __BLANK_FILENAME__ = False
        if __NAME__ == '':
            __BLANK_FILENAME__ = True
            __NAME__ = __TARGET_BASENAME__
               
        update_Ctrl(False)
        Btn_Exec.setEnabled(False)

        nonlocal worker
        worker = ConvertThread(__ORIGIN_FORMAT__, __TARGET_FORMAT__, __TARGET__, __OUTPUT__ or "", __NAME__)
        worker.progress.connect(Progress.setValue)
        worker.finished.connect(lambda err: Raistra.log(f'<font color=#999999>[信息]</font> 转化完成: {Path(__TARGET__).stem}.{__TARGET_FORMAT__}', s='Formatar'))
        worker.error.connect(lambda err: Raistra.log(f'<font color=#ff0000>[错误]</font> {err}', s='Formatar'))
        worker.finished.connect(lambda: update_Ctrl(True))
        worker.finished.connect(lambda: Progress.setValue(0))
        worker.finished.connect(Verfi_Target_Mulit)
        if __BLANK_FILENAME__:
            __NAME__ = ''
        worker.finished.connect(lambda: os.startfile(__OUTPUT__) if Toogle_OpenFolderAutomaticly.toggled else None)
        worker.finished.connect(worker.deleteLater)
        worker.error.connect(worker.deleteLater)
        worker.start()
        
    def Exec_Repeat():
        "批量转化"
        current_index = 0
        total = len(__TARGET_LIST__)
        Text_ExecM_Progress.show()

        def start_next():
            nonlocal current_index
            if current_index >= total:
                "工作完成"
                update_Ctrl(True)
                Raistra.log(f'<font color=#999999>[信息]</font> 批量转换完成: {total}个文件', s='Formatar')
                Progress.setValue(0)
                if Toogle_OpenFolderAutomaticly.toggled:
                    os.startfile(__OUTPUT__)
                Text_ExecM_Progress.hide()
                Text_ExecM_Progress.setText('')
                Verfi_Target()
                return

            __NAME__ = __TARGET_LIST__[current_index]   
            name = Path(__NAME__).stem
            Text_ExecM_Progress.setText(f'<font color=#999999>转化序列</font> {current_index+1}/{total} <font color=#999999>{__NAME__}</font>')
            nonlocal worker
            worker = ConvertThread(__ORIGIN_FORMAT__, __TARGET_FORMAT__, __NAME__, __OUTPUT__ or "", name)
            worker.progress.connect(Progress.setValue)
            worker.error.connect(lambda err: Raistra.log(f'<font color=#ff0000>[错误]</font> {err}', s='Formatar'))
            worker.finished.connect(lambda: start_next())
            worker.error.connect(lambda: start_next())
            worker.finished.connect(worker.deleteLater)
            worker.error.connect(worker.deleteLater)
            worker.start()
            current_index += 1

        "开始工作"
        start_next()
        update_Ctrl(False)
        
    __FORMAT_LIST_ORIGIN__ = ['mp4']
    __FORMAT_LIST_TARGET__ = ['mp3']
    Text_Type = QLabel(f'<font color=#999999>雨猫研制的神奇魔法让这个面板似乎有了转化文件的能力<br>选择模式, 填写一些参数, 你的文件就变成你想要的模样了~</font>')
    Layout.addWidget(Text_Type)
    
    "选择模式"
    Layout_Mode = QHBoxLayout()
    Layout.addLayout(Layout_Mode)
    
    Text_Mode = QLabel('<font color=#999999>模式</font>')
    Text_Mode.setMaximumWidth(60)
    Cbox_Mode = Raistra.RyWidget.ComboBox(list(__MODE_DICT__.values()))
    Text_Current_Mode = QLabel(Cbox_Mode.currentText())
    Text_Current_Mode.hide()
    Layout_Mode.addWidget(Text_Mode)
    Layout_Mode.addWidget(Cbox_Mode)
    Layout_Mode.addWidget(Text_Current_Mode)
    
    "模式: 格式转化"
    Layout_Format = QHBoxLayout()
    Text_Format = QLabel('<font color=#999999>格式</font>')
    Text_Format.setMaximumWidth(60)
    Cbox_Format_Origin = Raistra.RyWidget.ComboBox(__FORMAT_LIST_ORIGIN__)
    Cbox_Format_Origin.currentTextChanged.connect(Verfi_Format)
    Cbox_Format_Target = Raistra.RyWidget.ComboBox(__FORMAT_LIST_TARGET__)
    Cbox_Format_Target.currentTextChanged.connect(Verfi_Format)
    Text_Format_Convert = QLabel('> 转化 >')
    Text_Format_Convert.setMaximumWidth(60)
    Layout_Format.addWidget(Text_Format)
    Layout_Format.addWidget(Cbox_Format_Origin)
    Layout_Format.addWidget(Text_Format_Convert)
    Layout_Format.addWidget(Cbox_Format_Target)
    Verfi_Format()
    
    Layout.addLayout(Layout_Format)
    Layout.addStretch(1)
    
    "提示"
    Text_Tip = QLabel()
    Text_Tip.hide()
    Layout.addWidget(Text_Tip)
    
    "批量执行提示"
    Text_ExecM_Progress = QLabel()
    Text_ExecM_Progress.hide()
    Layout.addWidget(Text_ExecM_Progress)
    
    "进度条"
    Progress = QProgressBar()
    Layout.addWidget(Progress)
    Progress.setValue(0)
    
    "选取栏"
    Layout_pickup = QHBoxLayout()
    Layout.addLayout(Layout_pickup)
    
    Btn_Pick = Raistra.RyWidget.RPushButton('选择文件')
    Btn_Pick.pressed.connect(Select_File)
    Btn_Pick.hover.connect(lambda state: update_Tootip(state, f'<font color=#999999>已选定</font> {__TARGET__ if __TARGET__ else "无"} {f"<font color=#999999>大小</font> {(os.stat(__TARGET__).st_size)//1048576}<font color=#999999> MB" if __TARGET__ else ""}'))
    Layout_pickup.addWidget(Btn_Pick)
    Btn_Pick_Folder = Raistra.RyWidget.RPushButton('选择文件夹')
    Btn_Pick_Folder.pressed.connect(Select_Folder)
    Btn_Pick_Folder.hover.connect(lambda state: update_Tootip(state, f'<font color=#999999>已选定</font> {__TARGET_FOLDER__ if __TARGET_FOLDER__ else "无"} {f"<font color=#999999>文件数</font> {len(__TARGET_LIST__)}" if len(__TARGET_LIST__) else ""}<br><font color=#999999>将检索选定目录及子目录所有.{__ORIGIN_FORMAT__}文件'))
    Layout_pickup.addWidget(Btn_Pick_Folder)
    Btn_Exec = Raistra.RyWidget.RPushButton('转换')
    Btn_Exec.pressed.connect(Exec)
    Btn_Exec.hover.connect(lambda state: update_Tootip(state, f'<font color={__THEME__}>即将执行</font> <font color=#999999>文件</font> {__TARGET__}'))
    Layout_pickup.addWidget(Btn_Exec)
    Btn_Exec_Muilt = Raistra.RyWidget.RPushButton('批量转换')
    Btn_Exec_Muilt.pressed.connect(Exec_Repeat)
    Btn_Exec_Muilt.hover.connect(lambda state: update_Tootip(state, f'<font color={__THEME__}>即将执行</font> <font color=#999999>目录</font> {__TARGET_FOLDER__}<font color=#999999> 文件数</font> {len(__TARGET_LIST__)}'))
    Layout_pickup.addWidget(Btn_Exec_Muilt)
    Verfi_Target()
    Verfi_Target_Mulit()
    
    "选择&打开输出目录"
    Layout_OutputDir = QHBoxLayout()
    Layout.addLayout(Layout_OutputDir)
    
    Btn_Pick_Output = Raistra.RyWidget.RPushButton('选择输出目录')
    Btn_Pick_Output.pressed.connect(Select_OutputFolder)
    Btn_Pick_Output.hover.connect(lambda state: update_Tootip(state, f'<font color=#999999>已选定</font> {__OUTPUT__ if __OUTPUT__ else "当前文件夹"}'))
    Layout_OutputDir.addWidget(Btn_Pick_Output)
    
    Btn_Open_Output = Raistra.RyWidget.RPushButton('打开输出目录')
    Btn_Open_Output.pressed.connect(Open_OutputFolder)
    Btn_Open_Output.hover.connect(lambda state: update_Tootip(state, f'<font color=#999999>打开 {__OUTPUT__ if __OUTPUT__ else "当前文件夹"}'))
    Layout_OutputDir.addWidget(Btn_Open_Output)
    
    Toogle_OpenFolderAutomaticly = Raistra.RyWidget.RToggle('完成后打开文件夹', state=True)
    Toogle_OpenFolderAutomaticly.hover.connect(lambda state: update_Tootip(state, f'<font color=#999999>切换</font> 在转化结束后是否自动打开输出文件夹 <font color=#999999>当前值</font> {Toogle_OpenFolderAutomaticly.toggled}'))
    Toogle_OpenFolderAutomaticly.pressed.connect(lambda: update_Tootip(True ,f'<font color=#999999>切换</font> 在转化结束后是否自动打开输出文件夹 <font color=#999999>当前值</font> {Toogle_OpenFolderAutomaticly.toggled}'))
    Layout_OutputDir.addWidget(Toogle_OpenFolderAutomaticly)
    
    return Scroll