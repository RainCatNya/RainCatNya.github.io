"算法库"

import base64
def base64_encode(text: str):
    "Base64编码"
    return base64.b64encode(text.encode()).decode()
def base64_decode(text: str):
    "Base64解码"
    return base64.b64decode(text.encode()).decode()

from urllib.parse import quote, unquote
def url_encode(text: str):
    "URL编码"
    return quote(text)
def url_decode(text: str):
    "URL编码"
    return unquote(text)

def unicode_encode(text: str):
    "Unicode编码"
    return text.encode('unicode_escape').decode('ascii')
def unicode_decode(text: str):
    "Unicode解码"
    return text.encode('utf8').decode('unicode_escape')

import html
def html_encode(text: str):
    "HTML编码"
    return html.escape(text)
def html_decode(text: str):
    "HTML解码"
    return html.unescape(text)

def caesar_encrypt(text: str, shift: int) -> str:
    "凯撒密码 加密"
    result = []
    for ch in text:
        if ch.isupper():
            "大写字母: A(65) - Z(90)"
            result.append(chr((ord(ch) - 65 + shift) % 26 + 65))
        elif ch.islower():
            "小写字母: a(97) - z(122)"
            result.append(chr((ord(ch) - 97 + shift) % 26 + 97))
        else:
            "保留非字母字符"
            result.append(ch)
    return ''.join(result)
def caesar_decrypt(text:str, shift:int) -> str:
    "凯撒密码 解密"
    "倒转偏移量即可"
    return caesar_encrypt(text, -shift)

def xor_encrypt(text:str, key:str):
    "XOR加密"
    key = (key * (len(text) // len(key) + 1))[:len(text)]
    print(''.join(chr(ord(m) ^ ord(k)) for m, k in zip(text, key)))
    return ''.join(chr(ord(m) ^ ord(k)) for m, k in zip(text, key))

def xor_decrypt(text:str, key:str):
    "XOR解密"
    key = (key * (len(text) // len(key) + 1))[:len(text)]
    return ''.join(chr(ord(e) ^ ord(k)) for e, k in zip(text, key))