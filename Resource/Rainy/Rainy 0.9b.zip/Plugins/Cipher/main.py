from PyQt6.QtWidgets import (QWidget, QVBoxLayout,
    QLineEdit, QHBoxLayout, QLabel, QPushButton, QScrollArea, QComboBox)
from cipher_lib import *
from Scripts import Raistra

def build() -> QWidget:
    "Cipher 文本编码"
    
    "基本框架构建"
    Scroll = QScrollArea()
    Scroll.setWidgetResizable(True) 
    Container = QWidget()      
    Layout = QVBoxLayout(Container)
    Scroll.setWidget(Container) 
    
    __version__ = 'DEV_AND_OPTIMIZE'
    __theme__ = Raistra.__THEME__
    __author__ = '雨猫'
    
    "标题"
    Text_Title = QLabel(f'<font color={__theme__}>{build.__doc__}</font><br><font color=#777777><font size=2>版本 {__version__} by {__author__}')
    Layout.addWidget(Text_Title)
    
    "全部编码类型"
    __ENCODING__:tuple = ('base64', 'URL', 'Unicode', 'HTML')
    __CIPHER__:tuple = ('Caesar', 'XOR')
    __ASYMMETRIC__:tuple = ('RSA', 'IRS')
    "当前选择的编码类型"
    __ENCODING_TYPE__:str = __ENCODING__[0]
    __CIPHER_TYPE__:str = __CIPHER__[0]
    __ASYMMETRIC_TYPE__ = __ASYMMETRIC__[0]
    
    def update_Type(Type):
        "下拉框触发了不同选项时更新数据"
        if Type == 'ED':
            nonlocal __ENCODING_TYPE__
            __ENCODING_TYPE__ = __ENCODING__[Cbox_ED_Type.currentIndex()]
            "用灰色标记, 表明类型已更改, 文本不再对应"
            Text_ED_Current.setText(f'<font color=#666666>></font> {__ENCODING_TYPE__} <font color=#666666>></font>')
        elif Type == 'CH':
            nonlocal __CIPHER_TYPE__
            __CIPHER_TYPE__ = __CIPHER__[Cbox_CH_Type.currentIndex()]
            Text_CH_Current.setText(f'<font color=#666666>></font> {__CIPHER_TYPE__} <font color=#666666>></font>')
        
    def Endecoding(r: bool):
        "Encode/Decode 编/解码方法"
        "在这里声明Output防止后面的else条件把Output覆盖了"
        Output = ''
        try:
            if not r:
                "编码"
                Output = base64_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'base64' else Output
                Output = url_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'URL' else Output
                Output = unicode_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'Unicode' else Output
                Output = html_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'HTML' else Output
            else:
                "解码"
                Output = base64_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'base64' else Output
                Output = url_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'URL' else Output
                Output = unicode_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'Unicode' else Output
                Output = html_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'HTML' else Output
        except Exception as e:
            "标出红色箭头作警告"
            Text_ED_Current.setText(f'<font color=#ff0000>></font> {__ENCODING_TYPE__} <font color=#ff0000>></font>')
            Edit_ED_Output.setText('')
            return
            
        "Unicode编码可能返回"
        Edit_ED_Output.setText(Output)
        Text_ED_Current.setText(f'> {__ENCODING_TYPE__} >')
        
    def Ciphier(r: bool):
        "Ciphier 加/解密"
        Output = ''
        try:
            if not r:
                "加密"
                Output = caesar_encrypt(Edit_CH_Input.text(), int(Edit_CH_Key.text())) if __CIPHER_TYPE__ == 'Caesar' else Output
                Output = xor_encrypt(Edit_CH_Input.text(), Edit_CH_Key.text()) if __CIPHER_TYPE__ == 'XOR' else Output
                #Output = unicode_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'Unicode' else Output
                #Output = html_encode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'HTML' else Output
            else:
                "解密"
                Output = caesar_decrypt(Edit_CH_Input.text(), int(Edit_CH_Key.text())) if __CIPHER_TYPE__ == 'Caesar' else Output
                Output = xor_decrypt(Edit_CH_Input.text(), Edit_CH_Key.text()) if __CIPHER_TYPE__ == 'XOR' else Output
                #Output = unicode_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'Unicode' else Output
                #Output = html_decode(Edit_ED_Input.text()) if __ENCODING_TYPE__ == 'HTML' else Output
        except Exception as e:
            "标出红色箭头作警告"
            Text_CH_Current.setText(f'<font color=#ff0000>></font> {__CIPHER_TYPE__} <font color=#ff0000>></font>')
            Edit_CH_Output.setText('')
            return
            
        "Unicode编码可能返回"
        Edit_CH_Output.setText(Output)
        Text_CH_Current.setText(f'> {__CIPHER_TYPE__} >')
        
    def Asymmetric(r: bool):
        "Asymmetric Encryption 非对称加密"
    
    "编/解码"
    Text_ED = QLabel('String 编码/解码<font size=2><font color=#777777> ')
    Layout.addWidget(Text_ED)
    
    "编/解码 输入区域"
    Layout_ED_Input = QHBoxLayout()
    Edit_ED_Input = QLineEdit()
    "输入框内容变化时取消对应箭头"
    Edit_ED_Input.textChanged.connect(lambda: Text_ED_Current.setText(f'<font color=#666666>></font> {__ENCODING_TYPE__} <font color=#666666>></font>'))
    Layout_ED_Input.addWidget(Edit_ED_Input)
    
    Text_ED_Current = QLabel(f'<font color=#666666>></font> {__ENCODING_TYPE__} <font color=#666666>></font>')
    Layout_ED_Input.addWidget(Text_ED_Current)
    
    Edit_ED_Output = QLineEdit('')
    Layout_ED_Input.addWidget(Edit_ED_Output)
    Edit_ED_Output.setReadOnly(True)
    
    "编/解码 控制按钮"
    Layout_ED_Ctrl = QHBoxLayout()
    Btn_ED_Encode = QPushButton('编码')
    Btn_ED_Decode = QPushButton('反编码')
    Btn_ED_Encode.pressed.connect(lambda: Endecoding(False))
    Btn_ED_Decode.pressed.connect(lambda: Endecoding(True))
    Cbox_ED_Type = QComboBox()
    Cbox_ED_Type.addItems([i for i in __ENCODING__])
    #Cbox_ED_Type.buildTooltip(0, "Base64 编码/解码")
    Cbox_ED_Type.currentIndexChanged.connect(lambda: update_Type('ED'))
    
    Layout_ED_Ctrl.addWidget(Btn_ED_Encode)
    Layout_ED_Ctrl.addWidget(Btn_ED_Decode)
    Layout_ED_Ctrl.addWidget(Cbox_ED_Type)
    
    "添加编/解码布局"
    Layout.addLayout(Layout_ED_Input)
    Layout.addLayout(Layout_ED_Ctrl)
    
    "对称加密"
    Text_CH = QLabel('<br>String 对称加密<font size=2><font color=#777777> 需要唯一密钥')
    Layout.addWidget(Text_CH)
    
    "对称加密 输入区域"
    Layout_CH_Input = QHBoxLayout()
    Edit_CH_Input = QLineEdit()
    "输入框内容变化时取消对应箭头"
    Edit_CH_Input.textChanged.connect(lambda: Text_CH_Current.setText(f'<font color=#666666>></font> {__CIPHER_TYPE__} <font color=#666666>></font>'))
    Layout_CH_Input.addWidget(Edit_CH_Input)
    
    Text_CH_Current = QLabel(f'<font color=#666666>></font> {__CIPHER_TYPE__} <font color=#666666>></font>')
    Layout_CH_Input.addWidget(Text_CH_Current)
    
    Edit_CH_Output = QLineEdit('')
    Layout_CH_Input.addWidget(Edit_CH_Output)
    Edit_CH_Output.setReadOnly(True)
    
    "对称加密 控制按钮"
    Layout_CH_Ctrl = QHBoxLayout()
    Btn_CH_Encode = QPushButton('加密')
    Btn_CH_Decode = QPushButton('解密')
    Btn_CH_Encode.pressed.connect(lambda: Ciphier(False))
    Btn_CH_Decode.pressed.connect(lambda: Ciphier(True))
    Edit_CH_Key = QLineEdit()
    Edit_CH_Key.setMaximumWidth(200)
    Edit_CH_Key.setPlaceholderText('密钥')
    Cbox_CH_Type = QComboBox()
    Cbox_CH_Type.addItems([i for i in __CIPHER__])
    Cbox_CH_Type.currentIndexChanged.connect(lambda: update_Type('AE'))
    
    Layout_CH_Ctrl.addWidget(Btn_CH_Encode)
    Layout_CH_Ctrl.addWidget(Btn_CH_Decode)
    Layout_CH_Ctrl.addWidget(Edit_CH_Key)
    Layout_CH_Ctrl.addWidget(Cbox_CH_Type)
    Text_CH_Tip = QLabel('<font size=2><font color=#777777>* 在凯撒位移(Caesar)中ROT13较为常见, 连续加密或解密2次即可得到原文')
    
    Layout.addLayout(Layout_CH_Input)
    Layout.addLayout(Layout_CH_Ctrl)
    Layout.addWidget(Text_CH_Tip)
    
    "非对称加密"
    Text_AE = QLabel('<br>String 非对称加密<font size=2><font color=#777777> 需要公钥和密钥')
    Layout.addWidget(Text_AE)
    
    "非对称 输入区域"
    Layout_AE_Input = QHBoxLayout()
    Edit_AE_Input = QLineEdit()
    "输入框内容变化时取消对应箭头"
    Edit_AE_Input.textChanged.connect(lambda: Text_AE_Current.setText(f'<font color=#666666>></font> {__ASYMMETRIC_TYPE__} <font color=#666666>></font>'))
    Layout_AE_Input.addWidget(Edit_AE_Input)
    
    Text_AE_Current = QLabel(f'<font color=#666666>></font> {__ASYMMETRIC_TYPE__} <font color=#666666>></font>')
    Layout_AE_Input.addWidget(Text_AE_Current)
    
    Edit_AE_Output = QLineEdit('')
    Layout_AE_Input.addWidget(Edit_AE_Output)
    Edit_AE_Output.setReadOnly(True)
    
    "非对称 控制按钮"
    Layout_AE_Ctrl = QHBoxLayout()
    Btn_AE_Encode = QPushButton('加密')
    Btn_AE_Decode = QPushButton('解密')
    Btn_AE_Encode.pressed.connect(lambda: Ciphier(False))
    Btn_AE_Decode.pressed.connect(lambda: Ciphier(True))
    Edit_AE_PrivateKey = QLineEdit()
    Edit_AE_PrivateKey.setMaximumWidth(200)
    Edit_AE_PrivateKey.setPlaceholderText('私钥')
    Edit_AE_PublicKey = QLineEdit()
    Edit_AE_PublicKey.setMaximumWidth(200)
    Edit_AE_PublicKey.setPlaceholderText('公钥')
    Cbox_AE_Type = QComboBox()
    Cbox_AE_Type.addItems([i for i in __ASYMMETRIC__])
    Cbox_AE_Type.currentIndexChanged.connect(lambda: update_Type('CH'))
    
    Layout_AE_Ctrl.addWidget(Btn_AE_Encode)
    Layout_AE_Ctrl.addWidget(Btn_AE_Decode)
    Layout_AE_Ctrl.addWidget(Edit_AE_PrivateKey)
    Layout_AE_Ctrl.addWidget(Edit_AE_PublicKey)
    Layout_AE_Ctrl.addWidget(Cbox_AE_Type)
    #Text_AE_Tip = QLabel('<font size=2>')
    
    Layout.addLayout(Layout_AE_Input)
    Layout.addLayout(Layout_AE_Ctrl)
    #Layout.addWidget(Text_AE_Tip)
    
    Layout.addStretch(1)
    
    return Scroll