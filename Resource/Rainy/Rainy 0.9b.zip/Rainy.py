"Rainy 存储文件"
from PyQt6.QtWidgets import (QMainWindow, QApplication,
    QWidget, QVBoxLayout, QHBoxLayout, QStackedWidget, QLabel,
    QLineEdit)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QIcon
from Scripts import Raistra
"Raistra在这里就已初始化了"

class Rainy(QMainWindow):
    """*涟漪沁雨*  
    `Raincat`的工具箱"""
    
    __version__ = '0.93a'
    "`Rainy Version`"
    
    def __init__(self):
        "`Rainy`初始化"
        super().__init__()
        Raistra.blog('<br>初始化')
        Raistra.blog(f'<font color=#999999>Rainy 版本</font> {self.__version__}')
        Raistra.blog(f'<font color=#999999>Raistra 版本</font> {Raistra.__version__}')
        self.initAssets()
        self.initFrame()
        self.initPlugins()
        self.show()
                
    def initAssets(self) -> None:
        "加载资源"
        "别把Assets拼成Assests了!"
        self.setWindowTitle('Raincat 的万事屋')
        self.setWindowIcon(QIcon('Assets/Icon.png'))
        self.css_path = "Stylesheets/dark_violet.css"
        
        "读取样式表"
        self.setStyleSheet(Raistra.read_File(self.css_path))

        self.__THEME__ = Raistra.theme
        
    def initFrame(self) -> None:
        "构建图形框架"
        self.setFixedSize(1032, 639)
        Layout = QVBoxLayout()
        
        "中心部件"
        self.CentralWidget = QWidget()
        self.CentralWidget.setLayout(Layout)
        self.setCentralWidget(self.CentralWidget)

        "顶部区域"
        header_Area = QWidget()
        header_Area.setFixedHeight(41)
        header_Layout = QHBoxLayout(header_Area)

        "Rainy 标题"
        Title = QLabel(f'Rainy 工具箱 <font size=2><font color=#777777>版本 {self.__version__}</font></font>')
        header_Layout.addWidget(Title)
        header_Layout.addStretch(1)
        
        "身体布局~"
        body_Layout = QHBoxLayout()

        Sidebar = QWidget()
        Sidebar.setFixedWidth(45)
        self.Sidebar_Layout = QVBoxLayout(Sidebar)
        
        self.content_Area = QStackedWidget()
        self.content_Area.setProperty('b-color','Highlight')
        
        body_Layout.addWidget(Sidebar)
        body_Layout.addWidget(self.content_Area)    
        
        "添加Layout布局"
        Layout.addWidget(header_Area)
        Layout.addLayout(body_Layout)
        
        "构建日志"
        from Scripts import PgLogger
        self.Logger_Page = PgLogger.build(self.__THEME__)
        self.Logger_Trigger = Raistra.RyWidget.RPushButton(QIcon("Assets/terminal.png"), '')
        Log_Label = self.Logger_Page.findChild(QLabel, 'Log')
        Raistra.signal.sLog_update.connect(lambda: Log_Label.setText(Raistra._iLogger.getLog_html()))

        self.Logger_Trigger.setFixedSize(35,35)
        self.content_Area.addWidget(self.Logger_Page)
        self.Logger_Trigger.pressed.connect(lambda Page=self.Logger_Page: self.content_Area.setCurrentWidget(Page))
        Raistra.signal.sLog_Requested.connect(self.Logger_Trigger.show)
        Raistra.signal.sLog_Requested.connect(lambda: self.content_Area.setCurrentWidget(self.Logger_Page))
    
        
        "默认隐藏控制台"
        self.Logger_Trigger.hide()
        
        "构建设置"
        from Scripts import PgSettings
        Setting_Page = PgSettings.build(self.__THEME__)
        self.Setting_Trigger = Raistra.RyWidget.RPushButton(QIcon("Assets/whl.png"), '')
        self.Setting_Trigger.setFixedSize(35,35)
        self.Setting_Trigger.pressed.connect(lambda Page=Setting_Page: self.content_Area.setCurrentWidget(Page))
        
        self.content_Area.addWidget(Setting_Page)
        
    def initPlugins(self) -> None:     
        "加载插件"
        from Scripts.API_Plugin import Plugin
        PluginManager  = Plugin('Plugins')
        Raistra.blog('<br>加载插件')
        
        "创建Plugin实例并读取插件文件夹"
        pkg_data = PluginManager.run()
        for name, data in pkg_data.items():
            try:
                func = data['build']                
                Page = func()
                "创建页面自己的按钮"
                self.content_Area.addWidget(Page) if isinstance(Page, QWidget) else None
                Page_Trigger = Raistra.RyWidget.RPushButton()
                Page_Trigger.setIcon(QIcon(str(data['icon'])))
                Page_Trigger.setFixedSize(35,35)
                Page_Trigger.setIconSize(QSize(22,22))
                Page_Trigger.pressed.connect(lambda Page=Page: self.content_Area.setCurrentWidget(Page))
                self.Sidebar_Layout.addWidget(Page_Trigger)
            except Exception as e:
                "一般来说这个Exception不会触发, 除非上面的加载逻辑被哪个傻瓜动了"
                Raistra.log(f'构建插件 <font color=#ff0000>{name}</font> 时发生了未知错误: <font color=#ff6666>{e}</font>', lv=4)
                Raistra.blog(f'该异常可能由Rainy和Raistra插件的加载结构不一致导致, 请尝试更新你的Rainy版本!')
                Raistra.signal.sLog_Requested.emit()
                continue
        self.content_Area.setCurrentIndex(2)
           
        "将内置的插件添加到布局"
        self.Sidebar_Layout.addStretch(1)
        #self.Sidebar_Layout.addWidget(self.Setting_Trigger)
        self.Sidebar_Layout.addWidget(self.Logger_Trigger)
        
    def mousePressEvent(self, a0) -> None:
        "重写 Rainy 鼠标点击事件"
        focused_widget = QApplication.focusWidget()
        "当前点击的控件类不是QLineEdit时, 清除焦点"
        if isinstance(focused_widget, QLineEdit):
            "主要是为了防止QLineEdit的焦点不解除; 但同时会导致无法调出它的右键菜单"
            focused_widget.clearFocus()
        QMainWindow.mousePressEvent(self, a0)
        
    def keyPressEvent(self, event) -> None:
        "获取 Rainy 按键点击事件"
        key = event.key()
        if key == Qt.Key.Key_F1:
            "F1 调出开发者控制台"
            Raistra.signal.sLog_Requested.emit()
        elif key == Qt.Key.Key_Escape:
            "Esc 退出 Rainy"
            Raistra.signal.sShutdown.emit()
            
if __name__ == '__main__':
    Raistra.launch()